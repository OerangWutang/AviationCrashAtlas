/**
 * Shared layout primitives for AccidentDetailPanel sub-sections.
 *
 * Extracted so that DisputedSection, TimelineSection, and SourcesSection
 * can all import from one place rather than duplicating the markup.
 */
import type { ReactNode } from 'react';

export function SectionTitle({ children }: { children: ReactNode }) {
  return (
    <h3
      className="text-[11px] text-stone-400 uppercase tracking-wider mb-3 pb-1.5 border-b border-stone-100"
      style={{ fontFamily: 'var(--ff-mono)' }}
    >
      {children}
    </h3>
  );
}

export function Chip({ children }: { children: ReactNode }) {
  return (
    <span className="text-[11px] px-2.5 py-1 rounded-full border border-stone-200 bg-stone-50 text-stone-500">
      {children}
    </span>
  );
}
