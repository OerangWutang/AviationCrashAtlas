import Link from 'next/link';
import { useRouter } from 'next/router';
import ReviewerAuthControl from './ReviewerAuthControl';

const IS_MOCK = process.env.NEXT_PUBLIC_USE_MOCK === 'true';

const SOURCES = [
  { label: 'NTSB', active: true },
  { label: 'ASN (use generic-csv)', active: false },
  { label: 'ICAO (use generic-csv)', active: false },
];

interface Props {
  reviewerApiKey?: string;
  onReviewerApiKeyChange?: (apiKey: string) => void;
}

export default function Header({ reviewerApiKey, onReviewerApiKeyChange }: Props = {}) {
  const router = useRouter();

  const tabs = [
    { label: 'search', href: '/' },
    { label: 'map', href: '/map' },
    { label: 'analytics', href: '/analytics' },
    { label: 'sources', href: '/sources' },
    { label: 'conflicts', href: '/conflicts' },
    { label: 'operator', href: '/operator' },
  ];

  return (
    <header className="border-b border-stone-200 bg-white">
      <div className="flex items-center gap-4 px-5 py-3 flex-wrap">
        <Link href="/" className="text-[20px] leading-none" style={{ fontFamily: 'var(--ff-serif)' }}>
          Aviation{' '}
          <span className="italic text-[#185FA5]">Safety Atlas</span>
        </Link>

        <span
          className="text-[11px] text-stone-400"
          style={{ fontFamily: 'var(--ff-mono)' }}
        >
          v0.1.0-mvp
        </span>

        <div className="flex-1" />

        {onReviewerApiKeyChange && (
          <ReviewerAuthControl
            apiKey={reviewerApiKey ?? ''}
            onApiKeyChange={onReviewerApiKeyChange}
            compact
          />
        )}

        <div className="flex items-center gap-2">
          {SOURCES.map((s) => (
            <span
              key={s.label}
              className={`text-[10px] px-2 py-1 rounded border ${
                s.active
                  ? 'bg-blue-50 text-blue-700 border-blue-200'
                  : 'bg-stone-50 text-stone-400 border-stone-200'
              }`}
              style={{ fontFamily: 'var(--ff-mono)' }}
            >
              {s.label}
            </span>
          ))}
        </div>
      </div>

      {/* Nav tabs */}
      <div className="flex px-5 bg-stone-50 border-t border-stone-100">
        {tabs.map((tab) => {
          const active = router.pathname === tab.href;
          return (
            <Link
              key={tab.href}
              href={tab.href}
              className={`text-[12px] px-4 py-2.5 border-b-2 transition-colors ${
                active
                  ? 'border-[#185FA5] text-[#185FA5] font-medium'
                  : 'border-transparent text-stone-400 hover:text-stone-700'
              }`}
              style={{ fontFamily: 'var(--ff-mono)', marginBottom: '-1px' }}
            >
              {tab.label}
            </Link>
          );
        })}
      </div>
      {/* Mock-mode banner — visible on every page so users know data is demo-only */}
      {IS_MOCK && (
        <div
          className="bg-amber-50 border-t border-amber-200 px-5 py-1.5 text-[11px] text-amber-700 flex items-center gap-2"
          style={{ fontFamily: 'var(--ff-mono)' }}
        >
          <span className="font-semibold">⚠ DEMO MODE</span>
          <span>Displaying hardcoded sample data — not live aviation safety records.</span>
          <span className="text-amber-500">Set NEXT_PUBLIC_USE_MOCK=false and start the backend to view real data.</span>
        </div>
      )}
    </header>
  );
}
