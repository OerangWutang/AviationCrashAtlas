import { useState } from 'react';
import type { AccidentSummary, SearchFilters } from '../types';
import { PHASES } from '../lib/utils';
import ResultCard from './ResultCard';

interface Props {
  results: AccidentSummary[];
  total: number;
  page: number;
  hasNext: boolean;
  loading: boolean;
  selectedId: string | null;
  filters: SearchFilters;
  onFiltersChange: (f: SearchFilters) => void;
  onSelect: (a: AccidentSummary) => void;
  onPageChange: (p: number) => void;
}

export default function SearchSidebar({
  results, total, page, hasNext, loading,
  selectedId, filters, onFiltersChange, onSelect, onPageChange,
}: Props) {
  const set = (key: keyof SearchFilters) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    onFiltersChange({ ...filters, [key]: e.target.value });
  };

  const setBool = (key: keyof SearchFilters) => (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    onFiltersChange({ ...filters, [key]: e.target.checked });
  };

  return (
    <aside className="w-72 flex-shrink-0 border-r border-stone-200 flex flex-col bg-white">

      {/* Search */}
      <div className="p-3 border-b border-stone-100">
        <label
          className="block text-[10px] text-stone-400 uppercase tracking-wider mb-1.5"
          style={{ fontFamily: 'var(--ff-mono)' }}
        >
          Search
        </label>
        <div className="relative">
          <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 text-stone-300 w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input
            type="text"
            value={filters.q}
            onChange={set('q')}
            placeholder="aircraft, location, operator…"
            className="w-full text-[12px] pl-8 pr-3 py-1.5 border border-stone-200 rounded-md bg-stone-50 text-stone-700 placeholder-stone-300 focus:outline-none focus:ring-1 focus:ring-blue-300"
          />
        </div>
      </div>

      {/* Filters */}
      <div className="p-3 border-b border-stone-100 space-y-2.5">
        <label
          className="block text-[10px] text-stone-400 uppercase tracking-wider mb-1"
          style={{ fontFamily: 'var(--ff-mono)' }}
        >
          Filters
        </label>

        <FilterRow label="Severity">
          <select value={filters.severity} onChange={set('severity')} className="filter-select">
            <option value="">All severities</option>
            <option value="FATAL">Fatal</option>
            <option value="SERIOUS">Serious injury</option>
            <option value="MINOR">Minor injury</option>
            <option value="NONE">No injury</option>
          </select>
        </FilterRow>

        <FilterRow label="Phase of flight">
          <select value={filters.phase} onChange={set('phase')} className="filter-select">
            <option value="">All phases</option>
            {PHASES.map((p) => (
              <option key={p} value={p}>{p.charAt(0) + p.slice(1).toLowerCase()}</option>
            ))}
          </select>
        </FilterRow>

        <FilterRow label="Min completeness">
          <select value={filters.min_source_completeness} onChange={set('min_source_completeness')} className="filter-select">
            <option value="">Any</option>
            <option value="0.7">Mostly sourced (0.70+)</option>
            <option value="0.9">Well sourced (0.90+)</option>
          </select>
        </FilterRow>

        <FilterRow label="Fatalities">
          <select value={filters.fatality_status} onChange={set('fatality_status')} className="filter-select">
            <option value="">Any</option>
            <option value="some">Some fatalities</option>
            <option value="none">Confirmed none</option>
            <option value="unknown">Unknown</option>
          </select>
        </FilterRow>

        <FilterRow label="Year from">
          <input
            type="number"
            value={filters.year_from}
            onChange={set('year_from')}
            placeholder="e.g. 2015"
            min={1962}
            max={2100}
            className="filter-select"
          />
        </FilterRow>

        <FilterRow label="Registration">
          <input value={filters.registration ?? ''} onChange={set('registration')} placeholder="e.g. N123AB" className="filter-select" />
        </FilterRow>

        <FilterRow label="Aircraft type">
          <input value={filters.aircraft_type ?? ''} onChange={set('aircraft_type')} placeholder="make/model" className="filter-select" />
        </FilterRow>

        <FilterRow label="Operator">
          <input value={filters.operator ?? ''} onChange={set('operator')} placeholder="operator name" className="filter-select" />
        </FilterRow>

        <FilterRow label="Source ID">
          <input value={filters.source_id ?? ''} onChange={set('source_id')} placeholder="src-ntsb-001" className="filter-select" />
        </FilterRow>

        <label className="flex items-center gap-2 text-[11px] text-stone-500">
          <input type="checkbox" checked={!!filters.disputed_only} onChange={setBool('disputed_only')} />
          Disputed only
        </label>

        <label className="flex items-center gap-2 text-[11px] text-stone-500">
          <input type="checkbox" checked={!!filters.final_report_only} onChange={setBool('final_report_only')} />
          Verified final-report only
        </label>

        <FilterRow label="Sort by">
          <select value={filters.sort} onChange={set('sort')} className="filter-select">
            <option value="date_desc">Date (newest first)</option>
            <option value="date_asc">Date (oldest first)</option>
            <option value="source_completeness_desc">Source completeness (highest)</option>
            <option value="fatalities_desc">Fatalities (most)</option>
          </select>
        </FilterRow>
      </div>

      {/* Results count */}
      <div
        className="px-4 py-1.5 text-[10px] text-stone-400 border-b border-stone-100 bg-stone-50"
        style={{ fontFamily: 'var(--ff-mono)' }}
      >
        {loading ? 'loading…' : `${total.toLocaleString()} record${total !== 1 ? 's' : ''}`}
      </div>

      {/* Results list */}
      <div className="flex-1 sidebar-scroll">
        {loading ? (
          <div className="p-4 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="space-y-1.5">
                <div className="skeleton h-3 w-1/3" />
                <div className="skeleton h-4 w-full" />
                <div className="skeleton h-3 w-2/3" />
              </div>
            ))}
          </div>
        ) : results.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8 text-center">
            <div className="text-2xl mb-2">✈️</div>
            <div className="text-[13px] text-stone-400">No records match</div>
            <div className="text-[11px] text-stone-300 mt-1" style={{ fontFamily: 'var(--ff-mono)' }}>
              adjust filters
            </div>
          </div>
        ) : (
          results.map((a) => (
            <ResultCard
              key={a.id}
              accident={a}
              selected={selectedId === a.id}
              onClick={() => onSelect(a)}
            />
          ))
        )}
      </div>

      {/* Pagination */}
      <div className="flex items-center gap-2 px-3 py-2 border-t border-stone-100">
        <button
          disabled={page === 0}
          onClick={() => onPageChange(page - 1)}
          className="text-[12px] px-3 py-1 border border-stone-200 rounded bg-white text-stone-500 hover:bg-stone-50 disabled:opacity-30 disabled:cursor-not-allowed"
          style={{ fontFamily: 'var(--ff-mono)' }}
        >
          ←
        </button>
        <span
          className="flex-1 text-center text-[11px] text-stone-400"
          style={{ fontFamily: 'var(--ff-mono)' }}
        >
          page {page + 1}
        </span>
        <button
          disabled={!hasNext}
          onClick={() => onPageChange(page + 1)}
          className="text-[12px] px-3 py-1 border border-stone-200 rounded bg-white text-stone-500 hover:bg-stone-50 disabled:opacity-30 disabled:cursor-not-allowed"
          style={{ fontFamily: 'var(--ff-mono)' }}
        >
          →
        </button>
      </div>

      <style jsx>{`
        .filter-select {
          width: 100%;
          font-size: 12px;
          padding: 5px 8px;
          border: 1px solid #E7E5E0;
          border-radius: 6px;
          background: #FAFAF9;
          color: #44403C;
          font-family: var(--ff-sans);
          outline: none;
        }
        .filter-select:focus {
          border-color: #93C5FD;
          box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1);
        }
      `}</style>
    </aside>
  );
}

function FilterRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label
        className="block text-[11px] text-stone-400 mb-1"
      >
        {label}
      </label>
      {children}
    </div>
  );
}
