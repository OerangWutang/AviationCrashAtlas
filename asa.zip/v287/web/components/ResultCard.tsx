import type { AccidentSummary } from '../types';
import { formatOccurrenceDate, aircraftLabel } from '../lib/utils';
import ConfidenceBadge from './ConfidenceBadge';
import SeverityDot from './SeverityDot';

interface Props {
  accident: AccidentSummary;
  selected: boolean;
  onClick: () => void;
}

export default function ResultCard({ accident, selected, onClick }: Props) {
  const aircraft = aircraftLabel(accident.aircraft_make, accident.aircraft_model);

  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-4 py-3 border-b border-stone-100 result-card ${
        selected ? 'bg-blue-50' : 'hover:bg-stone-50'
      }`}
    >
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <div className="min-w-0">
          <div
            className="text-[10px] text-stone-400 mb-0.5"
            style={{ fontFamily: 'var(--ff-mono)' }}
          >
            {accident.canonical_id}
          </div>
          <div className="text-[13px] font-medium text-stone-800 leading-tight truncate">
            {aircraft}
          </div>
          <div className="text-[12px] text-stone-500 truncate">
            {accident.location_text ?? '—'}
          </div>
        </div>
        <ConfidenceBadge confidence={accident.confidence} />
      </div>

      <div
        className="flex items-center gap-2 text-[11px] text-stone-400 flex-wrap"
        style={{ fontFamily: 'var(--ff-mono)' }}
      >
        <span className="flex items-center gap-1">
          <SeverityDot severity={accident.injury_severity} />
          {accident.injury_severity ?? '—'}
        </span>
        <span className="text-stone-200">·</span>
        <span>{(() => {
          const { date, qualifier } = formatOccurrenceDate(
            accident.occurred_at, accident.occurred_date,
            accident.occurred_year, accident.occurred_at_precision,
          );
          return qualifier ? `${date} (${qualifier})` : date;
        })()}</span>
        <span className="text-stone-200">·</span>
        <span>{accident.phase_of_flight ?? '—'}</span>
      </div>
    </button>
  );
}
