import Head from 'next/head';
import { useState, useEffect } from 'react';
import Header from '../components/Header';
import { fetchAnalyticsSummary } from '../lib/api';
import { SEV_COLOR } from '../lib/utils';
import type { AnalyticsSummary } from '../types';

export default function AnalyticsPage() {
  const [summary, setSummary] = useState<AnalyticsSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK === 'true';

  useEffect(() => {
    if (USE_MOCK) {
      // Analytics requires real data from the backend.
      // Mock mode does not include aggregate statistics.
      setError('Analytics is not available in mock mode. Start the backend to view full-dataset statistics.');
      setLoading(false);
      return;
    }
    let cancelled = false;
    fetchAnalyticsSummary()
      .then((data) => { if (!cancelled) { setSummary(data); setLoading(false); } })
      .catch((err) => { if (!cancelled) { setError(String(err)); setLoading(false); } });
    return () => { cancelled = true; };
  }, [USE_MOCK]);

  // Map API shape to the stats shape the render code expects.
  // Use preferred source_completeness aliases; legacy avg_confidence / confidence_bins
  // are kept as fallbacks in case a cached API response precedes migration 0004.
  const stats = summary ? {
    fatal: summary.fatal_count,
    totalFatalities: summary.total_fatalities,
    avgConf: summary.avg_source_completeness ?? summary.avg_confidence,
    byPhase: summary.by_phase,
    bySev: summary.by_severity,
    confBins: [
      (summary.source_completeness_bins ?? summary.confidence_bins)['weakly_sourced'] ?? 0,
      (summary.source_completeness_bins ?? summary.confidence_bins)['partially_sourced'] ?? 0,
      (summary.source_completeness_bins ?? summary.confidence_bins)['mostly_sourced'] ?? 0,
      (summary.source_completeness_bins ?? summary.confidence_bins)['well_sourced'] ?? 0,
    ],
    byYear: summary.by_year,
    totalAccidents: summary.total_accidents,
  } : null;

  if (error) {
    return (
      <>
        <Head><title>Aviation Safety Atlas — Analytics</title></Head>
        <div className="flex flex-col h-screen">
          <Header />
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="max-w-md text-center">
              <div className="text-[13px] text-stone-500 font-mono mb-2">analytics unavailable</div>
              <div className="text-[13px] text-stone-600">{error}</div>
            </div>
          </div>
        </div>
      </>
    );
  }

  if (loading || !stats) {
    return (
      <>
        <Head><title>Aviation Safety Atlas — Analytics</title></Head>
        <div className="flex flex-col h-screen">
          <Header />
          <div className="flex-1 flex items-center justify-center">
            <div className="w-5 h-5 border-2 border-stone-200 border-t-[#185FA5] rounded-full animate-spin" />
          </div>
        </div>
      </>
    );
  }

  const maxPhase = Math.max(...Object.values(stats.byPhase), 1);
  const confLabels = ['Weakly sourced (<0.5)', 'Partially sourced (0.5–0.7)', 'Mostly sourced (0.7–0.9)', 'Well sourced (0.9+)'];
  const confColors = ['#E24B4A', '#EF9F27', '#378ADD', '#1D9E75'];
  const maxConf = Math.max(...stats.confBins, 1);

  return (
    <>
      <Head><title>Aviation Safety Atlas — Analytics</title></Head>
      <div className="flex flex-col h-screen overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-6">
          <h1
            className="text-[22px] text-stone-800 mb-6"
            style={{ fontFamily: 'var(--ff-serif)' }}
          >
            Analytics
          </h1>

          {/* Stat cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
            {[
              { label: 'total records', value: stats.totalAccidents.toLocaleString(), sub: 'NTSB sourced' },
              { label: 'fatal accidents', value: stats.fatal, sub: stats.totalAccidents > 0 ? `${((stats.fatal / stats.totalAccidents) * 100).toFixed(0)}% of records` : 'no records yet', color: '#E24B4A' },
              { label: 'total fatalities', value: stats.totalFatalities, sub: 'across all events' },
              { label: 'avg source completeness', value: stats.avgConf.toFixed(2), sub: 'all records' },
            ].map((s) => (
              <div key={s.label} className="bg-white border border-stone-200 rounded-xl p-4">
                <div
                  className="text-[10px] text-stone-400 uppercase tracking-wider mb-1"
                  style={{ fontFamily: 'var(--ff-mono)' }}
                >
                  {s.label}
                </div>
                <div
                  className="text-[26px] font-medium tabular-nums"
                  style={{ fontFamily: 'var(--ff-mono)', color: s.color ?? '#1C1B19' }}
                >
                  {s.value}
                </div>
                <div className="text-[11px] text-stone-400 mt-0.5">{s.sub}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Phase of flight */}
            <div className="bg-white border border-stone-200 rounded-xl p-5">
              <SectionTitle>Accidents by phase of flight</SectionTitle>
              <div className="space-y-2">
                {Object.entries(stats.byPhase)
                  .sort((a, b) => b[1] - a[1])
                  .map(([phase, count]) => (
                    <div key={phase} className="flex items-center gap-3">
                      <div
                        className="text-[11px] text-stone-400 text-right"
                        style={{ fontFamily: 'var(--ff-mono)', minWidth: 80 }}
                      >
                        {phase}
                      </div>
                      <div className="flex-1 h-4 bg-stone-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${(count / maxPhase) * 100}%`,
                            background: '#185FA5',
                            opacity: 0.75,
                          }}
                        />
                      </div>
                      <div
                        className="text-[11px] text-stone-500 tabular-nums"
                        style={{ fontFamily: 'var(--ff-mono)', minWidth: 20 }}
                      >
                        {count}
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            {/* Source completeness distribution */}
            <div className="bg-white border border-stone-200 rounded-xl p-5">
              <SectionTitle>Source completeness distribution</SectionTitle>
              <div className="space-y-2">
                {stats.confBins.map((count, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div
                      className="text-[11px] text-stone-400"
                      style={{ fontFamily: 'var(--ff-mono)', minWidth: 100 }}
                    >
                      {confLabels[i]}
                    </div>
                    <div className="flex-1 h-4 bg-stone-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${(count / maxConf) * 100}%`,
                          background: confColors[i],
                          opacity: 0.8,
                        }}
                      />
                    </div>
                    <div
                      className="text-[11px] tabular-nums"
                      style={{ fontFamily: 'var(--ff-mono)', color: confColors[i], minWidth: 20 }}
                    >
                      {count}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Severity breakdown */}
          <div className="bg-white border border-stone-200 rounded-xl p-5 mb-6">
            <SectionTitle>Injury severity breakdown</SectionTitle>
            <div className="flex gap-4 flex-wrap">
              {Object.entries(stats.bySev).map(([sev, count]) => (
                <div key={sev} className="flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ background: SEV_COLOR[sev] ?? '#888' }}
                  />
                  <span
                    className="text-[12px] text-stone-600"
                    style={{ fontFamily: 'var(--ff-mono)' }}
                  >
                    {sev}: {count}{stats.totalAccidents > 0 ? ` (${((count / stats.totalAccidents) * 100).toFixed(0)}%)` : ''}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Source note */}
          <div
            className="text-[11px] text-stone-300 text-center"
            style={{ fontFamily: 'var(--ff-mono)' }}
          >
            displaying {stats.totalAccidents} records · NTSB primary source · source-completeness-scored claim-based data
          </div>
        </main>
      </div>
    </>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h3
      className="text-[11px] text-stone-400 uppercase tracking-wider mb-4 pb-2 border-b border-stone-100"
      style={{ fontFamily: 'var(--ff-mono)' }}
    >
      {children}
    </h3>
  );
}
