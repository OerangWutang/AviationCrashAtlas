"""
ORM models for the claim-based aviation accident schema.

Key invariants enforced here:
- raw_snapshots are never mutated after insert
- claims are never deleted, only superseded or disputed
- accident_records is a derived projection, never a source of truth
- is_winning on Claim is set by ProjectionService, not by writers
"""
from __future__ import annotations

import enum
from datetime import date, datetime
from typing import Any

from geoalchemy2 import Geometry
from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


# ── Enumerations ──────────────────────────────────────────────────────────────

class ClaimType(enum.StrEnum):
    CONFIRMED  = "confirmed"   # directly stated in source
    INFERRED   = "inferred"    # derived from context
    DISPUTED   = "disputed"    # contradicted by another source — pending resolution
    REJECTED   = "rejected"    # explicitly discarded during conflict resolution
    SUPERSEDED = "superseded"  # source issued correction
    PENDING    = "pending"     # received, not yet reviewed


class RecordStatus(enum.StrEnum):
    ACTIVE    = "active"
    MERGED    = "merged"
    DISPUTED  = "disputed"
    RETRACTED = "retracted"


class InvestigationStatus(enum.StrEnum):
    PRELIMINARY    = "preliminary"
    FACTUAL        = "factual"
    PROBABLE_CAUSE = "probable_cause"
    FINAL          = "final"
    CLOSED         = "closed"


class DatePrecision(enum.StrEnum):
    EXACT = "exact"
    DAY   = "day"
    MONTH = "month"
    YEAR  = "year"


# ── Ingestion run ledger ───────────────────────────────────────────────────────

class IngestionRun(Base):
    """
    Durable operational record for each ingestion run.

    Answers operational questions:
      - When was NTSB last synced?
      - How many records changed?
      - Which records failed?
      - Which projection steps failed?
      - Which source is stale?

    A row is created at the start of each run (status='running') and updated
    to 'completed' or 'failed' at the end.  Errors are appended to the errors
    JSONB array.
    """
    __tablename__ = "ingestion_runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    source_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("sources.id"), nullable=True,
        comment="Which source was ingested (NULL for multi-source runs)",
    )
    source_name: Mapped[str] = mapped_column(String(50), nullable=False)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="running",
        comment="running | completed | failed",
    )
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    records_fetched: Mapped[int] = mapped_column(Integer, default=0)
    snapshots_new: Mapped[int] = mapped_column(Integer, default=0)
    snapshots_skipped: Mapped[int] = mapped_column(Integer, default=0)
    events_created: Mapped[int] = mapped_column(Integer, default=0)
    events_updated: Mapped[int] = mapped_column(Integer, default=0)
    claims_written: Mapped[int] = mapped_column(Integer, default=0)
    projection_errors: Mapped[int] = mapped_column(Integer, default=0)
    ingestion_errors: Mapped[int] = mapped_column(Integer, default=0)
    errors: Mapped[list[str] | None] = mapped_column(
        JSONB, default=None,
        comment="List of error strings from this run",
    )


# ── API key registry ──────────────────────────────────────────────────────────

class ApiKey(Base):
    """
    Hashed API keys used to authenticate operators against write endpoints.

    The raw key is generated once and shown to the operator; only the
    SHA-256 hex digest is stored.  Roles:
      reviewer — may resolve conflicts
      admin    — may do everything a reviewer can + future admin operations

    is_active=False revokes a key without deleting the audit record.
    """
    __tablename__ = "api_keys"
    __table_args__ = (
        Index("ix_api_key_hash", "key_hash", unique=True),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    key_hash: Mapped[str] = mapped_column(String(64), nullable=False, unique=True,
                                          comment="SHA-256 hex digest of the raw key")
    operator_id: Mapped[str] = mapped_column(String(100), nullable=False,
                                              comment="Human-readable identity (username/email)")
    role: Mapped[str] = mapped_column(String(20), nullable=False, default="reviewer",
                                      comment="reviewer | admin")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        comment="Optional expiry. NULL = never expires. Checked on every auth request.",
    )
    description: Mapped[str | None] = mapped_column(Text,
                                                     comment="Optional note about this key's purpose")




class Source(Base):
    __tablename__ = "sources"

    id: Mapped[str]  = mapped_column(String(36), primary_key=True)
    short_name: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    tier: Mapped[int] = mapped_column(Integer, nullable=False)
    license_type: Mapped[str] = mapped_column(String(50), nullable=False)
    base_url: Mapped[str | None] = mapped_column(Text)
    description: Mapped[str | None] = mapped_column(Text)
    ingestion_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_ingested_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    raw_snapshots: Mapped[list[RawSnapshot]] = relationship(back_populates="source")
    claims: Mapped[list[Claim]] = relationship(back_populates="source")


# ── Raw snapshots (immutable archive) ─────────────────────────────────────────

class RawSnapshot(Base):
    """
    Exact bytes received from a source — never mutated post-insert.
    payload_hash (SHA-256) makes ingestion idempotent.
    """
    __tablename__ = "raw_snapshots"
    __table_args__ = (
        UniqueConstraint("source_id", "payload_hash", name="uq_snapshot_source_hash"),
        Index("ix_snapshot_source_record", "source_id", "source_record_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    source_id: Mapped[str] = mapped_column(String(36), ForeignKey("sources.id"), nullable=False)
    source_record_id: Mapped[str | None] = mapped_column(String(200))
    ingested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    payload_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    source_url: Mapped[str | None] = mapped_column(Text)
    ingestion_run_id: Mapped[str | None] = mapped_column(String(36))

    source: Mapped[Source] = relationship(back_populates="raw_snapshots")
    claims: Mapped[list[Claim]] = relationship(back_populates="snapshot")


# ── Accident events ───────────────────────────────────────────────────────────

class AccidentEvent(Base):
    __tablename__ = "accident_events"
    __table_args__ = (
        Index("ix_event_location", "location_point", postgresql_using="gist"),
        Index("ix_event_occurred_at", "occurred_at"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    canonical_id: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    occurred_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=False))
    occurred_at_precision: Mapped[str] = mapped_column(String(10), default=DatePrecision.DAY.value)
    location_point: Mapped[Any | None] = mapped_column(Geometry("POINT", srid=4326))
    location_text: Mapped[str | None] = mapped_column(Text)
    country_code: Mapped[str | None] = mapped_column(String(3))
    overall_confidence_score: Mapped[float | None] = mapped_column(Numeric(4, 3))
    record_status: Mapped[str] = mapped_column(String(20), default=RecordStatus.ACTIVE.value)
    merged_into_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("accident_events.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    claims: Mapped[list[Claim]] = relationship(back_populates="event")
    conflicts: Mapped[list[ClaimConflict]] = relationship(back_populates="event")
    record: Mapped[AccidentRecord | None] = relationship(back_populates="event", uselist=False)
    source_documents: Mapped[list[SourceDocument]] = relationship(back_populates="event")


# ── Claims (the truth store) ──────────────────────────────────────────────────

class Claim(Base):
    """
    One field-level assertion from one source about one event.

    field_value is always a JSON envelope:
      {"v": <typed_value>, "type": "<python_type_name>"}

    Use claim_value.encode() / decode() to serialize/deserialize safely.
    Never write raw Python objects directly into field_value.
    """
    __tablename__ = "claims"
    __table_args__ = (
        Index("ix_claim_event_field", "event_id", "field_name"),
        Index("ix_claim_winning", "event_id", "is_winning"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    event_id: Mapped[str] = mapped_column(String(36), ForeignKey("accident_events.id"), nullable=False)
    source_id: Mapped[str] = mapped_column(String(36), ForeignKey("sources.id"), nullable=False)
    snapshot_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("raw_snapshots.id"))
    field_name: Mapped[str] = mapped_column(String(100), nullable=False)
    field_value: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    claim_type: Mapped[str] = mapped_column(String(20), nullable=False, default=ClaimType.CONFIRMED.value)
    confidence: Mapped[float | None] = mapped_column(Numeric(4, 3))
    effective_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_winning: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    event: Mapped[AccidentEvent] = relationship(back_populates="claims")
    source: Mapped[Source] = relationship(back_populates="claims")
    snapshot: Mapped[RawSnapshot | None] = relationship(back_populates="claims")
    history: Mapped[list[ClaimHistory]] = relationship(back_populates="claim")


class ClaimHistory(Base):
    """Immutable audit trail for every mutation to a Claim row."""
    __tablename__ = "claim_history"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    claim_id: Mapped[str] = mapped_column(String(36), ForeignKey("claims.id"), nullable=False)
    changed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    old_value: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    new_value: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    old_claim_type: Mapped[str | None] = mapped_column(String(20))
    new_claim_type: Mapped[str | None] = mapped_column(String(20))
    change_reason: Mapped[str | None] = mapped_column(Text)
    changed_by: Mapped[str | None] = mapped_column(String(100))

    claim: Mapped[Claim] = relationship(back_populates="history")


# ── Claim conflicts ───────────────────────────────────────────────────────────

class ClaimConflict(Base):
    __tablename__ = "claim_conflicts"
    __table_args__ = (
        Index("ix_conflict_event_field", "event_id", "field_name"),
        # Prevent duplicate rows if projection re-runs for the same event.
        # Claim IDs are canonicalised (min first) before insert so (A,B) and (B,A)
        # cannot both exist — see ClaimWriter._detect_conflicts.
        UniqueConstraint("event_id", "field_name", "claim_a_id", "claim_b_id",
                         name="uq_conflict_claim_pair"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    event_id: Mapped[str] = mapped_column(String(36), ForeignKey("accident_events.id"), nullable=False)
    field_name: Mapped[str] = mapped_column(String(100), nullable=False)
    claim_a_id: Mapped[str] = mapped_column(String(36), ForeignKey("claims.id"), nullable=False)
    claim_b_id: Mapped[str] = mapped_column(String(36), ForeignKey("claims.id"), nullable=False)

    # Lifecycle status — one of: "open" | "resolved" | "obsolete"
    # open: unresolved field disagreement, blocks projection of this field
    # resolved: manually accepted one claim as authoritative
    # obsolete: both conflicting claims have been superseded; no longer relevant
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="open")

    # Structured resolution — populated when status = "resolved"
    # These fields make the resolution auditable and prevent auto-reconciliation
    # from reinstating a claim that was explicitly rejected.
    resolution: Mapped[str | None] = mapped_column(Text)
    resolution_type: Mapped[str | None] = mapped_column(
        String(30),
        comment=(
            "claim_accepted | claim_rejected | claims_merged | "
            "source_corrected | not_applicable | manual_override"
        ),
    )
    accepted_claim_id: Mapped[str | None] = mapped_column(
        String(36),
        comment="The claim whose value was accepted as authoritative for this field",
    )
    rejected_claim_ids: Mapped[list[str] | None] = mapped_column(
        ARRAY(String(36)),
        comment="Claims explicitly rejected during resolution",
    )
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_by: Mapped[str | None] = mapped_column(String(100))

    # Obsolescence fields — populated when status = "obsolete"
    obsolete_reason: Mapped[str | None] = mapped_column(Text)
    obsolete_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    # Optimistic-lock counter — incremented on every state transition.
    # The resolve endpoint reads this value, checks it hasn't changed, then
    # increments it.  If two reviewers race on the same conflict the second
    # request will find status='resolved' (not 'open') and receive a 409.
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    event: Mapped[AccidentEvent] = relationship(back_populates="conflicts")


# ── Accident records (read projection) ───────────────────────────────────────

class AccidentRecord(Base):
    """
    Denormalized read-projection rebuilt from winning claims by ProjectionService.
    NEVER write to this table directly. Always rebuild via ProjectionService.

    confidence_breakdown stores the full factor list so the API can expose
    why a score is what it is — fixes the "confidence theater" problem.
    """
    __tablename__ = "accident_records"
    __table_args__ = (
        Index("ix_record_occurred_at", "occurred_at"),
        Index("ix_record_location", "location_point", postgresql_using="gist"),
        Index("ix_record_severity", "injury_severity"),
        Index("ix_record_confidence", "confidence_score"),
    )

    id: Mapped[str] = mapped_column(String(36), ForeignKey("accident_events.id"), primary_key=True)

    # Temporal
    # occurred_at stores the local accident time as a timezone-naive datetime.
    # NTSB source times are local to the accident site; we do not know the UTC
    # offset at ingestion time.  DateTime(timezone=False) prevents the driver
    # from silently attaching a false UTC offset.
    # occurred_at_precision records how fine-grained the time value is:
    #   "exact" = date + HH:MM parsed from source
    #   "day"   = date only (no time component)
    #   "year"  = only the year is known
    occurred_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=False))
    occurred_date: Mapped[date | None] = mapped_column(Date)
    occurred_year: Mapped[int | None] = mapped_column(Integer)
    occurred_at_precision: Mapped[str | None] = mapped_column(String(10))

    # Spatial — PostGIS point AND raw floats for API responses (fixes map breakage)
    location_point: Mapped[Any | None] = mapped_column(Geometry("POINT", srid=4326))
    location_lat: Mapped[float | None] = mapped_column(Numeric(9, 6))
    location_lon: Mapped[float | None] = mapped_column(Numeric(9, 6))
    location_text: Mapped[str | None] = mapped_column(Text)
    country_code: Mapped[str | None] = mapped_column(String(3))
    state_code: Mapped[str | None] = mapped_column(String(10))

    # Aircraft
    aircraft_make: Mapped[str | None] = mapped_column(String(200))
    aircraft_model: Mapped[str | None] = mapped_column(String(200))
    aircraft_registration: Mapped[str | None] = mapped_column(String(20))
    aircraft_amateur_built: Mapped[bool | None] = mapped_column(Boolean)

    # Operator
    operator_name: Mapped[str | None] = mapped_column(String(300))

    # Flight
    phase_of_flight: Mapped[str | None] = mapped_column(String(50))
    purpose_of_flight: Mapped[str | None] = mapped_column(String(100))
    weather_condition: Mapped[str | None] = mapped_column(String(20))

    # Outcome
    injury_severity: Mapped[str | None] = mapped_column(String(20))
    fatalities_total: Mapped[int | None] = mapped_column(Integer)
    fatalities_crew: Mapped[int | None] = mapped_column(Integer)
    fatalities_passengers: Mapped[int | None] = mapped_column(Integer)
    serious_injuries: Mapped[int | None] = mapped_column(Integer)
    serious_injuries_crew: Mapped[int | None] = mapped_column(Integer)
    serious_injuries_passengers: Mapped[int | None] = mapped_column(Integer)
    minor_injuries: Mapped[int | None] = mapped_column(Integer)
    minor_injuries_crew: Mapped[int | None] = mapped_column(Integer)
    minor_injuries_passengers: Mapped[int | None] = mapped_column(Integer)
    uninjured_crew: Mapped[int | None] = mapped_column(Integer)
    uninjured_passengers: Mapped[int | None] = mapped_column(Integer)
    aboard_total: Mapped[int | None] = mapped_column(Integer)
    aircraft_damage: Mapped[str | None] = mapped_column(String(20))

    # Investigation
    investigation_status: Mapped[str | None] = mapped_column(String(30))
    probable_cause: Mapped[str | None] = mapped_column(Text)
    contributing_factors: Mapped[list[str] | None] = mapped_column(ARRAY(Text))
    ntsb_report_number: Mapped[str | None] = mapped_column(String(50))

    # Provenance
    # source_ids: sources behind *winning* projected field values only.
    # claim_source_ids: all sources that contributed any non-superseded claim.
    source_ids: Mapped[list[str] | None] = mapped_column(ARRAY(String(36)))
    claim_source_ids: Mapped[list[str] | None] = mapped_column(
        ARRAY(String(36)), comment="All sources with non-superseded claims, including non-winning"
    )
    primary_source_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sources.id"))
    confidence_score: Mapped[float | None] = mapped_column(Numeric(4, 3))
    confidence_breakdown: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB, comment="Stored factor list so API can expose full score explanation"
    )
    has_conflicts: Mapped[bool] = mapped_column(Boolean, default=False)
    # v20: per-field projection rationale (selection_reason codes).
    # Persisted alongside the projection so the API can surface "why is
    # this value displayed?" without recomputing the rationale on each
    # request.  See migration 0009 for the row shape.
    projection_explanations: Mapped[list[dict[str, Any]] | None] = mapped_column(
        JSONB,
        comment="Per-field projection rationale list; see ProjectionService.",
    )
    # v20: aggregate label over SourceDocument rows for this event.
    # Backed by migration 0009.  Nullable while older rows wait for the
    # next projection rebuild to populate it.
    document_status: Mapped[str | None] = mapped_column(
        Text,
        comment="One of: none_linked | linked_unverified | verified | unavailable | mixed.",
    )
    last_projected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    event: Mapped[AccidentEvent] = relationship(back_populates="record")


# ── Source documents ──────────────────────────────────────────────────────────

class SourceDocument(Base):
    """
    Links to official source documents. URL health checked periodically.
    Only link to URLs that have been verified to exist — never fabricate.
    """
    __tablename__ = "source_documents"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    event_id: Mapped[str] = mapped_column(String(36), ForeignKey("accident_events.id"), nullable=False)
    source_id: Mapped[str] = mapped_column(String(36), ForeignKey("sources.id"), nullable=False)
    document_type: Mapped[str] = mapped_column(String(30), nullable=False)
    url: Mapped[str] = mapped_column(Text, nullable=False)
    url_verified: Mapped[bool] = mapped_column(
        Boolean, default=False,
        comment="True only after a successful HTTP HEAD check — never set on construction"
    )
    title: Mapped[str | None] = mapped_column(Text)
    published_at: Mapped[date | None] = mapped_column(Date)
    is_available: Mapped[bool | None] = mapped_column(Boolean)
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # Verification metadata — populated by check-links command
    last_http_status: Mapped[int | None] = mapped_column(
        Integer, comment="HTTP status code from most recent check (e.g. 200, 404, 403)"
    )
    last_check_error: Mapped[str | None] = mapped_column(
        Text, comment="Error message or failure reason from most recent check"
    )
    last_check_method: Mapped[str | None] = mapped_column(
        String(10), comment="HTTP method used: HEAD or GET (HEAD→GET fallback)"
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    event: Mapped[AccidentEvent] = relationship(back_populates="source_documents")
    source: Mapped[Source] = relationship()


# ── Event revisions (timeline) ────────────────────────────────────────────────

class EventRevision(Base):
    """
    Append-only human-readable timeline of changes for a single accident
    event.  Distinct from claim_history (per-claim, structured) — this
    table feeds the "How this record evolved" UI strip.

    See migration 0008 for the documented revision_type values.

    Each row is the result of one observable change: a snapshot first
    seen, a snapshot's content changing, a claim being superseded, a
    conflict opening, a document becoming unavailable, etc.  The
    description column is what the UI displays; old/new value plus
    field_names give consumers enough structure to render their own
    formatting if desired.
    """
    __tablename__ = "event_revisions"
    __table_args__ = (
        Index("ix_event_revisions_event_at", "event_id", "occurred_at"),
        Index("ix_event_revisions_run", "ingestion_run_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    event_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("accident_events.id", ondelete="CASCADE"),
        nullable=False,
    )
    # Loose string discriminator — values documented in migration 0008.
    revision_type: Mapped[str] = mapped_column(String(50), nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    source_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("sources.id"), nullable=True
    )
    source_record_id: Mapped[str | None] = mapped_column(String(200), nullable=True)
    snapshot_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("raw_snapshots.id"), nullable=True
    )
    claim_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("claims.id"), nullable=True
    )
    conflict_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("claim_conflicts.id"), nullable=True
    )
    source_document_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("source_documents.id"), nullable=True
    )
    ingestion_run_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("ingestion_runs.id"), nullable=True
    )
    field_names: Mapped[list[str] | None] = mapped_column(ARRAY(Text), nullable=True)
    old_value: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    new_value: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)


# ── Source-record rolling state ───────────────────────────────────────────────

class SourceRecordState(Base):
    """
    Rolling per-source-record state derived from raw_snapshots.

    raw_snapshots is the immutable archive: one row per unique
    payload_hash for a given source.  This table is the aggregate that
    answers "what did source X's record Y look like the last time we
    fetched it, and when did that content actually change?"

    On every ingest we update last_seen_at; we update last_changed_at and
    current_payload_hash only when the new payload differs.  The
    previous_payload_hash + current_field_names columns let the
    revision-builder diff the prior canonical field set against the new
    one to detect added / removed / changed fields without re-reading
    the raw payload.
    """
    __tablename__ = "source_record_state"
    __table_args__ = (
        Index("ix_source_record_state_event", "event_id"),
    )

    source_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("sources.id"), primary_key=True
    )
    source_record_id: Mapped[str] = mapped_column(String(200), primary_key=True)
    event_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("accident_events.id"), nullable=True
    )
    first_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    last_changed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    current_payload_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    current_snapshot_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("raw_snapshots.id"), nullable=True
    )
    previous_payload_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    parser_version: Mapped[str] = mapped_column(
        String(40), nullable=False, server_default="1"
    )
    current_field_names: Mapped[list[str] | None] = mapped_column(
        ARRAY(Text), nullable=True
    )


# ── Duplicate review workflow ─────────────────────────────────────────────────

class DuplicateCandidateReview(Base):
    """Reviewable candidate saying two events may describe the same accident.

    Medium-confidence cross-source matches are intentionally not merged
    automatically. They are stored here so reviewers can confirm or reject the
    relationship and so rejected pairs are not suggested repeatedly.
    """
    __tablename__ = "duplicate_candidates"
    __table_args__ = (
        Index("ix_duplicate_candidates_status", "status", "created_at"),
        Index("ix_duplicate_candidates_events", "source_event_id", "candidate_event_id"),
        UniqueConstraint(
            "source_event_id", "candidate_event_id",
            name="uq_duplicate_candidate_event_pair",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    source_event_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("accident_events.id"), nullable=True,
        comment="New/incoming event that may be duplicate; nullable for parser-only candidates",
    )
    candidate_event_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("accident_events.id"), nullable=False,
        comment="Existing event suggested as the likely duplicate target",
    )
    source_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sources.id"), nullable=True)
    source_record_id: Mapped[str | None] = mapped_column(String(200), nullable=True)
    ingestion_run_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("ingestion_runs.id"), nullable=True)
    match_type: Mapped[str] = mapped_column(String(40), nullable=False, default="fuzzy")
    match_score: Mapped[float] = mapped_column(Numeric(5, 3), nullable=False)
    match_reasons: Mapped[list[str] | None] = mapped_column(JSONB, nullable=True)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="pending",
        comment="pending | confirmed | rejected | obsolete",
    )
    decision_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    reviewed_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class DuplicateMergeOperation(Base):
    """Audit record for a confirmed duplicate merge that can be undone."""
    __tablename__ = "duplicate_merge_operations"
    __table_args__ = (
        Index("ix_duplicate_merge_operations_candidate", "duplicate_candidate_id"),
        Index("ix_duplicate_merge_operations_events", "source_event_id", "target_event_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    duplicate_candidate_id: Mapped[str] = mapped_column(String(36), ForeignKey("duplicate_candidates.id"), nullable=False)
    source_event_id: Mapped[str] = mapped_column(String(36), ForeignKey("accident_events.id"), nullable=False)
    target_event_id: Mapped[str] = mapped_column(String(36), ForeignKey("accident_events.id"), nullable=False)
    moved_claim_ids: Mapped[list[str]] = mapped_column(JSONB, nullable=False, default=list)
    moved_document_ids: Mapped[list[str]] = mapped_column(JSONB, nullable=False, default=list)
    moved_revision_ids: Mapped[list[str]] = mapped_column(JSONB, nullable=False, default=list)
    moved_conflict_ids: Mapped[list[str]] = mapped_column(JSONB, nullable=False, default=list)
    moved_issue_ids: Mapped[list[str]] = mapped_column(JSONB, nullable=False, default=list)
    created_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    undone_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    undone_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    undo_note: Mapped[str | None] = mapped_column(Text, nullable=True)


class EventExternalId(Base):
    """Stable source-specific IDs linked to a canonical event."""
    __tablename__ = "event_external_ids"
    __table_args__ = (
        UniqueConstraint(
            "source_id", "external_id_type", "external_id",
            name="uq_event_external_id_source_type_value",
        ),
        Index("ix_event_external_ids_event", "event_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    event_id: Mapped[str] = mapped_column(String(36), ForeignKey("accident_events.id"), nullable=False)
    source_id: Mapped[str] = mapped_column(String(36), ForeignKey("sources.id"), nullable=False)
    external_id_type: Mapped[str] = mapped_column(String(50), nullable=False, default="source_record_id")
    external_id: Mapped[str] = mapped_column(String(200), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class DataQualityIssue(Base):
    """Reviewable data-quality warning derived from claims or projections."""
    __tablename__ = "data_quality_issues"
    __table_args__ = (
        Index("ix_data_quality_event_status", "event_id", "status"),
        Index("ix_data_quality_code", "issue_code"),
        UniqueConstraint(
            "event_id", "issue_code", "field_name", "status",
            name="uq_open_data_quality_issue",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    event_id: Mapped[str] = mapped_column(String(36), ForeignKey("accident_events.id"), nullable=False)
    source_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sources.id"), nullable=True)
    issue_code: Mapped[str] = mapped_column(String(80), nullable=False)
    field_name: Mapped[str] = mapped_column(String(100), nullable=False)
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="warning")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="open")
    details: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    resolved_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
    resolution_note: Mapped[str | None] = mapped_column(Text, nullable=True)


class ArchiveManifest(Base):
    """Manifest row for a retention/archive export run."""
    __tablename__ = "archive_manifests"
    __table_args__ = (
        Index("ix_archive_manifests_created", "created_at"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    archive_type: Mapped[str] = mapped_column(String(40), nullable=False, default="retention")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="created")
    cutoff_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    output_uri: Mapped[str] = mapped_column(Text, nullable=False)
    manifest: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[str | None] = mapped_column(String(100), nullable=True)
